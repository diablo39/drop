package testtest;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

import io.github.swagger2markup.GroupBy;
import io.github.swagger2markup.Swagger2MarkupConfig;
import io.github.swagger2markup.Swagger2MarkupConverter;
import io.github.swagger2markup.builder.Swagger2MarkupConfigBuilder;
import io.github.swagger2markup.markup.builder.MarkupLanguage;

public class Main {

	public static void main(String[] args) {

		URL remoteSwaggerFile;
		try {
			remoteSwaggerFile = new URL("http://petstore.swagger.io/v2/swagger.json");

			Path outputDirectory = Paths.get("E:/temp/build/asciidoc");

			Swagger2MarkupConfig config = new Swagger2MarkupConfigBuilder() 
			        .withMarkupLanguage(MarkupLanguage.MARKDOWN) 
			        .withPathsGroupedBy(GroupBy.TAGS) 
			        .build();
			
			Swagger2MarkupConverter.from(remoteSwaggerFile).withConfig(config).build().toFolder(outputDirectory);

		} catch (MalformedURLException e) {

			e.printStackTrace();
		}
	}

}
